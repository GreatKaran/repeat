# TagChecker
A telegram tag verifier bot, which can verify that user has your community tag or not.

# Deploy-to-Heroku 
[![Deploy To Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/TgxBotz/TagChecker/blob/main)

# Telegram Support Chat
[![Telegram](https://img.shields.io/badge/telegram-1b77FF.svg?style=for-the-badge&logo=telegram)](https://t.me/TheTelegramChats)
